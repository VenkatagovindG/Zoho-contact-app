<?php
				$host = "localhost";
				$username = "root";
				$password = "";
				$db="cuser";
				
				// Create connection
				$conn = mysqli_connect($host, $username, $password,$db);
				
				// Check connection
				if (!$conn) {
				  die("Connection failed: " . mysqli_connect_error());
				}


                else{
                $SELECT ="SELECT phonenumber From info where phonenumber=? Limit 1";
                $INSERT ="INSERT Into info(unname,phonenumber,email)values(?,?,?)";


				$stmt=$conn->prepare($SELECT);
                $stmt->bind_param("i",$phonenumber);
                $stmt->execute();
                $stmt-bind_result($phonenumber);
                $stmt->store_result();
                $rnum=$stmt->num_rows;


                if($rnum==0){
                    $stmt->close();
                    $stmt=$conn->prepare($INSERT);
                    $stmt->bind_param("sis",$unname,$phonenumber,$email);
                    $stmt->execute();
                    echo "contact saved"
                } else{    
                  echo"contact not saved";
                }
                $stmt->close();
                $conn->close();
             }
            else{
                die();
            }
			?>