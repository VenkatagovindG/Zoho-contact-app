<?php
nysql_connect('localhost','root','')
mysql_select_db('demo')
?>